'use strict';

const AWS = require('aws-sdk');

exports.handler =  function(event, context, callback) {
    let ssm = new AWS.SSM();
    const token = event.authorizationToken;
    var zoom_signature;
    var params = {
        Name: '/zoom/signature',
        WithDecryption: true
    };
    
    ssm.getParameter(params, function(err, data) {
        if (err) 
            console.log(err, err.stack); 
        else     
            //console.log(data);
            zoom_signature = data['Parameter']['Value'];
            
            if (token === zoom_signature) {
                callback(null, generatePolicy('user', 'Allow', event.methodArn));
            } else if (token !== zoom_signature) {
                callback("Unauthorized");   // Return a 401 Unauthorized response
            } else {
                callback("Error: Invalid token"); // Return a 500 Invalid token response
            }
    });
};

// Help function to generate an IAM policy
var generatePolicy = function(principalId, effect, resource) {
    var authResponse = {};
    
    authResponse.principalId = principalId;
    if (effect && resource) {
        var policyDocument = {};
        policyDocument.Version = '2012-10-17'; 
        policyDocument.Statement = [];
        var statementOne = {};
        statementOne.Action = 'execute-api:Invoke'; 
        statementOne.Effect = effect;
        statementOne.Resource = resource;
        policyDocument.Statement[0] = statementOne;
        authResponse.policyDocument = policyDocument;
    }
    
    return authResponse;
};